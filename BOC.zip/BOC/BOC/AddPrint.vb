﻿Public Class AddPrint
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Register.Show()
        Me.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        payroll.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        EmpTrain.Show()
        Me.Hide()

    End Sub

    Private Sub AddPrint_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim a As DialogResult

        a = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If a = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

End Class