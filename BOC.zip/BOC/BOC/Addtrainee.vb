﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient
Public Class Addtrainee
    Dim con As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim dr As MySqlDataReader

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles insert.Click

        For i As Integer = 0 To DataGridView1.Rows.Count - 1

            If traineeID.Text = DataGridView1.Rows(i).Cells(0).Value.ToString() Then

                MessageBox.Show("ID Already in Use")
                Return

            End If

        Next


        Try
            Dim con As New MySqlConnection
            Dim cmd As New MySqlCommand
            Dim dr As MySqlDataReader
            con.ConnectionString = "server=localhost;username=root;password=;database=boc"

            con.Open()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from trainee where  TraineeId='" & traineeID.Text & "'"
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                MsgBox("Trainee Id Already Registered", MsgBoxStyle.Critical)
                con.Close()
            Else
                con.Close()
                con.Open()
                cmd.CommandText = "INSERT INTO trainee (`TraineeId`, `firstname`, `lastname`, `address`, `gender`, `emailaddress`, `cellphoneno`) VALUES
                ('" & traineeID.Text & "', '" & TextBox2.Text & "', '" & TextBox3.Text & "',
             '" & TextBox4.Text & "', '" & ComboBox1.SelectedItem & "', '" & TextBox6.Text & "', '" & cpnum.Text & "')"
                If (TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.SelectedItem = "" Or TextBox6.Text = "" Or cpnum.Text = "") Then
                    MessageBox.Show("Please enter the details")
                Else
                    cmd.ExecuteNonQuery()
                    MsgBox("Successfully Added.", MsgBoxStyle.Information, "Added")

                    traineeID.Clear()
                    TextBox2.Clear()
                    TextBox3.Clear()
                    TextBox4.Clear()
                    ComboBox1.SelectedIndex = -1
                    TextBox6.Clear()
                    cpnum.Clear()

                End If
                con.Close()
            End If
            con.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try

        Dim str As String

        Try

            str = "SELECT * FROM trainee"

            con.Open()

            Dim da As New MySqlDataAdapter(str, con)

            Dim dt As New DataTable

            da.Fill(dt)

            DataGridView1.DataSource = dt

            con.Close()


        Catch ex As Exception

            MsgBox(ex.Message)

            con.Close()

        End Try

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles clear.Click

        traineeID.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        ComboBox1.SelectedIndex = -1
        TextBox6.Clear()
        cpnum.Clear()

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles delete.Click

        If traineeID.Text = "" Then

            MessageBox.Show("Please input a Trainee ID to delete a data")

        Else

            con = New MySqlConnection
            con.ConnectionString = "server=localhost;username=root;password=;database=boc"
            Dim reader As MySqlDataReader

            Try
                con.Open()
                Dim query As String

                query = " Delete from trainee where TraineeId='" & traineeID.Text & "'"

                cmd = New MySqlCommand(query, con)
                reader = cmd.ExecuteReader

                MessageBox.Show("Data Delete Successful")
                con.Close()
                traineeID.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox4.Clear()
                ComboBox1.SelectedIndex = -1
                TextBox5.Clear()
                TextBox6.Clear()
                cpnum.Clear()


            Catch ex As Exception
                MessageBox.Show(ex.Message)

            Finally
                con.Dispose()

            End Try

            Try

                con.Open()
                Dim querryy As String
                querryy = "Alter Table trainee AUTO_INCREMENT = 1"
                cmd = New MySqlCommand(querryy, con)
                reader = cmd.ExecuteReader()

                con.Close()

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Dim str As String

            Try

                str = "SELECT * FROM trainee"

                con.Open()

                Dim da As New MySqlDataAdapter(str, con)

                Dim dt As New DataTable

                da.Fill(dt)

                DataGridView1.DataSource = dt

                con.Close()


            Catch ex As Exception

                MsgBox(ex.Message)

                con.Close()

            End Try

        End If

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles update.Click

        If (traineeID.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.SelectedItem = "" Or TextBox6.Text = "" Or cpnum.Text = "") Then

            MessageBox.Show("Please enter the complete details to update")

        Else

            con = New MySqlConnection
            con.ConnectionString = "server=localhost; username=root; password=; database=boc"
            Dim reader As MySqlDataReader
            Try

                con.Open()
                Dim query As String
                query = "update trainee set TraineeId='" & traineeID.Text & "', firstname='" & TextBox2.Text & "', lastname='" & TextBox3.Text & "', address='" & TextBox4.Text & "', gender='" & ComboBox1.SelectedItem & "' , emailaddress='" & TextBox6.Text & "' , cellphoneno='" & cpnum.Text & "' where TraineeId='" & traineeID.Text & "' "
                cmd = New MySqlCommand(query, con)
                reader = cmd.ExecuteReader()

                MessageBox.Show("Data Save Successfully!")
                con.Close()
                traineeID.Clear()
                TextBox2.Clear()
                TextBox3.Clear()
                TextBox4.Clear()
                ComboBox1.SelectedIndex = -1
                TextBox5.Clear()
                TextBox6.Clear()
                cpnum.Clear()


            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Dim str As String

            Try

                str = "SELECT * FROM trainee"

                con.Open()

                Dim da As New MySqlDataAdapter(str, con)

                Dim dt As New DataTable

                da.Fill(dt)

                DataGridView1.DataSource = dt

                con.Close()


            Catch ex As Exception

                MsgBox(ex.Message)

                con.Close()

            End Try

        End If

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        ''con = New MySqlConnection
        ''cmd = con.CreateCommand()
        ''con.ConnectionString = "server=localhost;username=root;password=;database=boc"

        ''cmd.CommandType = CommandType.Text
        ''cmd.CommandText = "select * from trainee where TraineeId='" & TextBox5.Text & "'"
        ''con.Open()
        ''con.Close()

        ''If TextBox5.Text = "" Then
        ''MsgBox("Please enter a Trainee ID to Search")
        ''Exit Sub
        ''End If


        ''Dim dt As New DataTable()
        ''Dim mydata As New MySqlDataAdapter(cmd)

        ''mydata.Fill(dt)
        ''DataGridView1.DataSource = dt

        If TextBox5.Text = "" Then

            MessageBox.Show("Please enter a Trainee ID to Search")

        Else

            Dim con As New MySqlConnection
            Dim cmd As New MySqlCommand
            Dim read As MySqlDataReader

            con.ConnectionString = "server=localhost;username=root;password=;database=boc"

            con.Open()
            Dim query As String = "select * from trainee where TraineeId='" & TextBox5.Text & "'"
            cmd = New MySqlCommand(query, con)
            read = cmd.ExecuteReader()

            If read.Read = Nothing Then

                MessageBox.Show("Trainee ID is not recognize by the database")

                TextBox5.Text = ""
                con.Close()


                Dim strr As String

                Try

                    strr = "SELECT * FROM trainee"

                    con.Open()

                    Dim da As New MySqlDataAdapter(strr, con)

                    Dim dt As New DataTable

                    da.Fill(dt)

                    DataGridView1.DataSource = dt

                    con.Close()


                Catch ex As Exception

                    MsgBox(ex.Message)

                    con.Close()

                End Try

            Else

                con = New MySqlConnection
                cmd = con.CreateCommand()
                con.ConnectionString = "server=localhost;username=root;password=;database=boc"

                cmd.CommandType = CommandType.Text
                cmd.CommandText = "select * from trainee where TraineeId='" & TextBox5.Text & "'"
                con.Open()
                con.Close()


                Dim ddt As New DataTable()
                Dim mydataa As New MySqlDataAdapter(cmd)

                mydataa.Fill(ddt)
                DataGridView1.DataSource = ddt

            End If

        End If

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try

            If e.RowIndex >= 0 Then

                Dim row As DataGridViewRow
                row = Me.DataGridView1.Rows(e.RowIndex)
                traineeID.Text = row.Cells("TraineeID").Value.ToString
                TextBox2.Text = row.Cells("FirstName").Value.ToString
                TextBox3.Text = row.Cells("LastName").Value.ToString
                TextBox4.Text = row.Cells("Address").Value.ToString
                ComboBox1.SelectedItem = row.Cells("Gender").Value.ToString
                TextBox6.Text = row.Cells("EmailAddress").Value.ToString
                cpnum.Text = row.Cells("CellphoneNo").Value.ToString

            End If

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub Addtrainee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        con = New MySqlConnection
        cmd = con.CreateCommand()
        con.ConnectionString = "server=localhost;username=root;password=;database=boc"

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from trainee"
        con.Open()
        con.Close()

        Dim dt As New DataTable()
        Dim mydata As New MySqlDataAdapter(cmd)

        mydata.Fill(dt)
        DataGridView1.DataSource = dt

    End Sub

    Private Sub traineeID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles traineeID.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub cpnum_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cpnum.KeyPress

        If cpnum.Text.Length > 10 Then

            MessageBox.Show("Contact Number should not be more than 11 numbers")
            e.Handled = True
            Return

        End If

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub back_Click(sender As Object, e As EventArgs) Handles back.Click

        addtrain2.Show()
        Me.Hide()

        traineeID.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        ComboBox1.SelectedIndex = -1
        TextBox6.Clear()
        cpnum.Clear()
        TextBox5.Clear()

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

        Dim str As String

        Try

            str = "SELECT * FROM trainee"

            con.Open()

            Dim da As New MySqlDataAdapter(str, con)

            Dim dt As New DataTable

            da.Fill(dt)

            DataGridView1.DataSource = dt

            con.Close()


        Catch ex As Exception

            MsgBox(ex.Message)

            con.Close()

        End Try

    End Sub

    Private Sub TextBox5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox5.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 65 Or Asc(e.KeyChar) > 90 And Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then

                e.Handled = True
                MessageBox.Show("You can only input letters in this field")

            End If

        End If

    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 65 Or Asc(e.KeyChar) > 90 And Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then

                e.Handled = True
                MessageBox.Show("You can only input letters in this field")

            End If

        End If

    End Sub

    Private Sub Addtrainee_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Dim d As DialogResult

        d = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If d = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

    Private Sub print_bttn_Click(sender As Object, e As EventArgs) Handles print.Click

        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
        PrintPreviewDialog1.ShowDialog()

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()
        Me.ErrorProvider4.Clear()
        Me.ErrorProvider5.Clear()
        Me.ErrorProvider6.Clear()
        Me.ErrorProvider7.Clear()

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        Dim imagebmp As New Bitmap(Me.DataGridView1.Width, Me.DataGridView1.Height)
        DataGridView1.DrawToBitmap(imagebmp, New Rectangle(0, 0, Me.DataGridView1.Width, Me.DataGridView1.Height))
        e.Graphics.DrawImage(imagebmp, 0, 0)

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

        Dim str As String

        Try

            str = "SELECT * FROM trainee"

            con.Open()

            Dim da As New MySqlDataAdapter(str, con)

            Dim dt As New DataTable

            da.Fill(dt)

            DataGridView1.DataSource = dt

            con.Close()


        Catch ex As Exception

            MsgBox(ex.Message)

            con.Close()

        End Try

    End Sub

    Private Sub TextBox2_Validating(sender As Object, e As CancelEventArgs) Handles TextBox2.Validating

        If String.IsNullOrEmpty(TextBox2.Text.Trim) Then

            ErrorProvider1.SetError(TextBox2, "First Name is required")

        Else

            ErrorProvider1.SetError(TextBox2, String.Empty)

        End If

    End Sub

    Private Sub TextBox3_Validating(sender As Object, e As CancelEventArgs) Handles TextBox3.Validating

        If String.IsNullOrEmpty(TextBox3.Text.Trim) Then

            ErrorProvider2.SetError(TextBox3, "Last Name is required")

        Else

            ErrorProvider2.SetError(TextBox3, String.Empty)

        End If

    End Sub

    Private Sub TextBox4_Validating(sender As Object, e As CancelEventArgs) Handles TextBox4.Validating

        If String.IsNullOrEmpty(TextBox4.Text.Trim) Then

            ErrorProvider3.SetError(TextBox4, "Address is required")

        Else

            ErrorProvider3.SetError(TextBox4, String.Empty)

        End If

    End Sub

    Private Sub ComboBox1_Validating(sender As Object, e As CancelEventArgs) Handles ComboBox1.Validating

        If String.IsNullOrEmpty(ComboBox1.Text.Trim) Then

            ErrorProvider4.SetError(ComboBox1, "Gender is required")

        Else

            ErrorProvider4.SetError(ComboBox1, String.Empty)

        End If

    End Sub

    Private Sub TextBox6_Validating(sender As Object, e As CancelEventArgs) Handles TextBox6.Validating

        If String.IsNullOrEmpty(TextBox6.Text.Trim) Then

            ErrorProvider5.SetError(TextBox6, "Email Address is required")

        Else

            ErrorProvider5.SetError(TextBox6, String.Empty)

        End If

    End Sub

    Private Sub cpnum_Validating(sender As Object, e As CancelEventArgs) Handles cpnum.Validating

        If String.IsNullOrEmpty(cpnum.Text.Trim) Then

            ErrorProvider6.SetError(cpnum, "Cellphone Number is required")

        Else

            ErrorProvider6.SetError(cpnum, String.Empty)

        End If

    End Sub

    Private Sub TextBox5_Validating(sender As Object, e As CancelEventArgs) Handles TextBox5.Validating

        If String.IsNullOrEmpty(TextBox5.Text.Trim) Then

            ErrorProvider7.SetError(TextBox5, "Trainee ID is required")

        Else

            ErrorProvider7.SetError(TextBox5, String.Empty)

        End If

    End Sub

End Class