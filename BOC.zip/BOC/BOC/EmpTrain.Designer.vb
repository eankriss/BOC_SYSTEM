﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EmpTrain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EmpTrain))
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.emp_bttn = New System.Windows.Forms.Button()
        Me.changepass_bttn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DarkGray
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(278, 223)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(156, 50)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Trainee"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DarkGray
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(281, 383)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(148, 46)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Log out"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button3.UseVisualStyleBackColor = False
        '
        'emp_bttn
        '
        Me.emp_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.emp_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.emp_bttn.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.emp_bttn.Image = CType(resources.GetObject("emp_bttn.Image"), System.Drawing.Image)
        Me.emp_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.emp_bttn.Location = New System.Drawing.Point(273, 140)
        Me.emp_bttn.Name = "emp_bttn"
        Me.emp_bttn.Size = New System.Drawing.Size(169, 50)
        Me.emp_bttn.TabIndex = 3
        Me.emp_bttn.Text = "Employee"
        Me.emp_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.emp_bttn.UseVisualStyleBackColor = False
        '
        'changepass_bttn
        '
        Me.changepass_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.changepass_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.changepass_bttn.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.changepass_bttn.Image = CType(resources.GetObject("changepass_bttn.Image"), System.Drawing.Image)
        Me.changepass_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.changepass_bttn.Location = New System.Drawing.Point(224, 304)
        Me.changepass_bttn.Name = "changepass_bttn"
        Me.changepass_bttn.Size = New System.Drawing.Size(271, 46)
        Me.changepass_bttn.TabIndex = 4
        Me.changepass_bttn.Text = "Change Password"
        Me.changepass_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.changepass_bttn.UseVisualStyleBackColor = False
        '
        'EmpTrain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = Global.BOC.My.Resources.Resources.FB23035B_CF03_4089_A137_C8A6152F9DEC
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(711, 517)
        Me.Controls.Add(Me.changepass_bttn)
        Me.Controls.Add(Me.emp_bttn)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "EmpTrain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Dashboard"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents emp_bttn As Button
    Friend WithEvents changepass_bttn As Button
End Class
