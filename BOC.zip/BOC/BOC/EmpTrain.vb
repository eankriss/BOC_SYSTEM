﻿Public Class EmpTrain
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Dim b As DialogResult

        b = MessageBox.Show("Do you really want to close this system?", "Logout", MessageBoxButtons.YesNo)

        If b = Windows.Forms.DialogResult.No Then

            Me.Show()

        Else

            Login.Show()
            Me.Hide()

        End If

        ''If MsgBox("Do you want to logout?", vbYesNo + vbQuestion) = vbYes Then

        ''Login.Show()
        ''Me.Hide()

        ''End If


    End Sub

    Private Sub emp_bttn_Click(sender As Object, e As EventArgs) Handles emp_bttn.Click
        AddPrint.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        addtrain2.Show()
        Me.Hide()

    End Sub


    Private Sub EmpTrain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim b As DialogResult

        b = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If b = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles changepass_bttn.Click

        ChangePass.Show()
        Me.Hide()

    End Sub

End Class