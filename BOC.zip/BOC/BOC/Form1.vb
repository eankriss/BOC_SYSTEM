﻿Public Class Form1
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        Me.ProgressBar1.Value = ProgressBar1.Value + 3

        If ProgressBar1.Value = 99 Then

            Timer1.Stop()
            Login.Show()
            Me.Hide()

        Else

            Label2.Text = ProgressBar1.Value & "% Completing..."

        End If

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Timer1.Enabled = True

    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        If Timer1.Enabled = False Then

            Timer1.Enabled = True

        Else

            Timer1.Enabled = False

        End If

        Dim c As DialogResult

        c = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If c = Windows.Forms.DialogResult.No Then

            e.Cancel = True
            Timer1.Start()

        Else

            Timer1.Stop()
            Application.ExitThread()

        End If

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
