﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient
Public Class Login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox1.Text = "" And TextBox2.Text = "" Then

            MessageBox.Show("Please input credentials!")
            ErrorProvider1.SetError(TextBox1, "Username is required")
            ErrorProvider2.SetError(TextBox2, "Password is required")

        ElseIf TextBox1.Text = "" And TextBox2.Text IsNot "" Then

            MessageBox.Show("Please input Username!")
            ErrorProvider1.SetError(TextBox1, "Username is required")

        ElseIf TextBox2.Text = "" And TextBox1.Text IsNot "" Then

            MessageBox.Show("Please input Password!")
            ErrorProvider2.SetError(TextBox2, "Password is required")

        Else

            Dim con As New MySqlConnection
            Dim cmd As New MySqlCommand
            Dim read As MySqlDataReader

            con.ConnectionString = "server=localhost;username=root;password=;database=boc"
            Try

                con.Open()
                Dim query As String = "select * from account where username='" & TextBox1.Text & "' AND password ='" & TextBox2.Text & "'"
                cmd = New MySqlCommand(query, con)
                ''Dim myadapt As New MySqlDataAdapter(cmd)''
                '' Dim dt As DataTable = New DataTable()''
                read = cmd.ExecuteReader()

                If read.Read = Nothing Then

                    MessageBox.Show("Username or Password not recognize by the database!")

                Else

                    ''myadapt.Fill(dt)''
                    EmpTrain.Show()
                    TextBox1.Clear()
                    TextBox2.Clear()
                    Me.Hide()

                End If

                con.Close()

            Catch ex As Exception
                ''MsgBox(ex.ToString)''
            End Try

        End If

        If CheckBox1.Checked = True Then

            CheckBox1.Checked = False

        End If

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then

            TextBox2.UseSystemPasswordChar = False

        Else

            TextBox2.UseSystemPasswordChar = True

        End If

    End Sub

    Private Sub Login_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim d As DialogResult

        d = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If d = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox1.KeyDown

        If e.KeyCode = Keys.Enter Then

            Button1_Click(Nothing, Nothing)

        Else

            Exit Sub

        End If

    End Sub

    Private Sub TextBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox2.KeyDown

        If e.KeyCode = Keys.Enter Then

            Button1_Click(Nothing, Nothing)

        Else

            Exit Sub

        End If

    End Sub

    Private Sub TextBox1_Validating(sender As Object, e As CancelEventArgs) Handles TextBox1.Validating

        If String.IsNullOrEmpty(TextBox1.Text.Trim) Then

            ErrorProvider1.SetError(TextBox1, "Username is required")

        Else

            ErrorProvider1.SetError(TextBox1, String.Empty)

        End If

    End Sub

    Private Sub TextBox2_Validating(sender As Object, e As CancelEventArgs) Handles TextBox2.Validating

        If String.IsNullOrEmpty(TextBox2.Text.Trim) Then

            ErrorProvider2.SetError(TextBox2, "Password is required")

        Else

            ErrorProvider2.SetError(TextBox2, String.Empty)

        End If

    End Sub

End Class