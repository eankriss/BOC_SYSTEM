﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Pay
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Pay))
        Me.empname = New System.Windows.Forms.Label()
        Me.empid = New System.Windows.Forms.Label()
        Me.Pid = New System.Windows.Forms.Label()
        Me.En = New System.Windows.Forms.Label()
        Me.start = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PS = New System.Windows.Forms.Label()
        Me.PE = New System.Windows.Forms.Label()
        Me.TI = New System.Windows.Forms.Label()
        Me.TN = New System.Windows.Forms.Label()
        Me.AL = New System.Windows.Forms.Label()
        Me.PI = New System.Windows.Forms.Label()
        Me.TAL = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'empname
        '
        Me.empname.AutoSize = True
        Me.empname.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.empname.Location = New System.Drawing.Point(227, 288)
        Me.empname.Name = "empname"
        Me.empname.Size = New System.Drawing.Size(0, 13)
        Me.empname.TabIndex = 57
        '
        'empid
        '
        Me.empid.AutoSize = True
        Me.empid.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.empid.Location = New System.Drawing.Point(227, 256)
        Me.empid.Name = "empid"
        Me.empid.Size = New System.Drawing.Size(0, 13)
        Me.empid.TabIndex = 56
        '
        'Pid
        '
        Me.Pid.AutoSize = True
        Me.Pid.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pid.Location = New System.Drawing.Point(575, 233)
        Me.Pid.Name = "Pid"
        Me.Pid.Size = New System.Drawing.Size(0, 13)
        Me.Pid.TabIndex = 55
        '
        'En
        '
        Me.En.AutoSize = True
        Me.En.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.En.Location = New System.Drawing.Point(227, 219)
        Me.En.Name = "En"
        Me.En.Size = New System.Drawing.Size(0, 13)
        Me.En.TabIndex = 54
        '
        'start
        '
        Me.start.AutoSize = True
        Me.start.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.start.Location = New System.Drawing.Point(227, 187)
        Me.start.Name = "start"
        Me.start.Size = New System.Drawing.Size(0, 13)
        Me.start.TabIndex = 53
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(-5, 368)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(1453, 13)
        Me.Label11.TabIndex = 52
        Me.Label11.Text = resources.GetString("Label11.Text")
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(-5, 256)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(1453, 13)
        Me.Label10.TabIndex = 51
        Me.Label10.Text = resources.GetString("Label10.Text")
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(61, 341)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(98, 13)
        Me.Label9.TabIndex = 50
        Me.Label9.Text = "Trainee Name:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(63, 288)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 13)
        Me.Label8.TabIndex = 49
        Me.Label8.Text = "Trainee ID:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(382, 200)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(84, 13)
        Me.Label7.TabIndex = 48
        Me.Label7.Text = "Payroll ID:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(63, 233)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(84, 13)
        Me.Label6.TabIndex = 47
        Me.Label6.Text = "Period End:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(61, 187)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 13)
        Me.Label5.TabIndex = 46
        Me.Label5.Text = "Period Start:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(-5, 170)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(1453, 13)
        Me.Label4.TabIndex = 45
        Me.Label4.Text = resources.GetString("Label4.Text")
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(233, 142)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(189, 13)
        Me.Label3.TabIndex = 44
        Me.Label3.Text = "Cellphone No.: 09157183388"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(177, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(315, 13)
        Me.Label2.TabIndex = 43
        Me.Label2.Text = "McArthur Highway, Sampaloc, Apalit Pampanga "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("NSimSun", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(194, 75)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(282, 27)
        Me.Label1.TabIndex = 42
        Me.Label1.Text = "BLACK OLIVES CAFE "
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImage = Global.BOC.My.Resources.Resources._281543298_1198849467545975_1994038224335913503_n
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox1.Location = New System.Drawing.Point(-400, 129)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(146, 139)
        Me.PictureBox1.TabIndex = 41
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImage = Global.BOC.My.Resources.Resources._281543298_1198849467545975_1994038224335913503_n
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PictureBox2.Location = New System.Drawing.Point(25, 27)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(146, 139)
        Me.PictureBox2.TabIndex = 58
        Me.PictureBox2.TabStop = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(382, 410)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(119, 13)
        Me.Label12.TabIndex = 60
        Me.Label12.Text = "Total Allowance:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(61, 410)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 13)
        Me.Label13.TabIndex = 59
        Me.Label13.Text = "Allowance:"
        '
        'PS
        '
        Me.PS.AutoSize = True
        Me.PS.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PS.Location = New System.Drawing.Point(196, 187)
        Me.PS.Name = "PS"
        Me.PS.Size = New System.Drawing.Size(0, 13)
        Me.PS.TabIndex = 61
        '
        'PE
        '
        Me.PE.AutoSize = True
        Me.PE.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PE.Location = New System.Drawing.Point(196, 233)
        Me.PE.Name = "PE"
        Me.PE.Size = New System.Drawing.Size(0, 13)
        Me.PE.TabIndex = 62
        '
        'TI
        '
        Me.TI.AutoSize = True
        Me.TI.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TI.Location = New System.Drawing.Point(196, 288)
        Me.TI.Name = "TI"
        Me.TI.Size = New System.Drawing.Size(0, 13)
        Me.TI.TabIndex = 63
        '
        'TN
        '
        Me.TN.AutoSize = True
        Me.TN.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TN.Location = New System.Drawing.Point(196, 341)
        Me.TN.Name = "TN"
        Me.TN.Size = New System.Drawing.Size(0, 13)
        Me.TN.TabIndex = 64
        '
        'AL
        '
        Me.AL.AutoSize = True
        Me.AL.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AL.Location = New System.Drawing.Point(196, 410)
        Me.AL.Name = "AL"
        Me.AL.Size = New System.Drawing.Size(0, 13)
        Me.AL.TabIndex = 65
        '
        'PI
        '
        Me.PI.AutoSize = True
        Me.PI.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PI.Location = New System.Drawing.Point(498, 200)
        Me.PI.Name = "PI"
        Me.PI.Size = New System.Drawing.Size(0, 13)
        Me.PI.TabIndex = 66
        '
        'TAL
        '
        Me.TAL.AutoSize = True
        Me.TAL.Font = New System.Drawing.Font("NSimSun", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TAL.Location = New System.Drawing.Point(498, 410)
        Me.TAL.Name = "TAL"
        Me.TAL.Size = New System.Drawing.Size(0, 13)
        Me.TAL.TabIndex = 67
        '
        'Pay
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(626, 561)
        Me.Controls.Add(Me.TAL)
        Me.Controls.Add(Me.PI)
        Me.Controls.Add(Me.AL)
        Me.Controls.Add(Me.TN)
        Me.Controls.Add(Me.TI)
        Me.Controls.Add(Me.PE)
        Me.Controls.Add(Me.PS)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.empname)
        Me.Controls.Add(Me.empid)
        Me.Controls.Add(Me.Pid)
        Me.Controls.Add(Me.En)
        Me.Controls.Add(Me.start)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Pay"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Payslip"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents empname As Label
    Friend WithEvents empid As Label
    Friend WithEvents Pid As Label
    Friend WithEvents En As Label
    Friend WithEvents start As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents PS As Label
    Friend WithEvents PE As Label
    Friend WithEvents TI As Label
    Friend WithEvents TN As Label
    Friend WithEvents AL As Label
    Friend WithEvents PI As Label
    Friend WithEvents TAL As Label
End Class
