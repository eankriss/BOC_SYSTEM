﻿Public Class Pay
    Private Sub Pay_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Pay_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Dim d As DialogResult

        d = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If d = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub
End Class