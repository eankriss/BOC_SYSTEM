﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PayTrainee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PayTrainee))
        Me.Tname = New System.Windows.Forms.TextBox()
        Me.Tid = New System.Windows.Forms.TextBox()
        Me.payrollid = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PeriodEnd = New System.Windows.Forms.DateTimePicker()
        Me.PeriodStart = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.back_bttn = New System.Windows.Forms.Button()
        Me.insert_bttn = New System.Windows.Forms.Button()
        Me.payslip_bttn = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.allwnc = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Total = New System.Windows.Forms.TextBox()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.update_bttn = New System.Windows.Forms.Button()
        Me.delete_bttn = New System.Windows.Forms.Button()
        Me.clear_bttn = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Tname
        '
        Me.Tname.Location = New System.Drawing.Point(298, 176)
        Me.Tname.Name = "Tname"
        Me.Tname.Size = New System.Drawing.Size(181, 20)
        Me.Tname.TabIndex = 20
        '
        'Tid
        '
        Me.Tid.Location = New System.Drawing.Point(80, 176)
        Me.Tid.Name = "Tid"
        Me.Tid.Size = New System.Drawing.Size(181, 20)
        Me.Tid.TabIndex = 19
        '
        'payrollid
        '
        Me.payrollid.AutoSize = True
        Me.payrollid.BackColor = System.Drawing.Color.Transparent
        Me.payrollid.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.payrollid.ForeColor = System.Drawing.SystemColors.Window
        Me.payrollid.Location = New System.Drawing.Point(612, 39)
        Me.payrollid.Name = "payrollid"
        Me.payrollid.Size = New System.Drawing.Size(0, 17)
        Me.payrollid.TabIndex = 16
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Window
        Me.Label3.Location = New System.Drawing.Point(518, 39)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 17)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Payroll ID:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Window
        Me.Label2.Location = New System.Drawing.Point(202, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Period End:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Window
        Me.Label1.Location = New System.Drawing.Point(202, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 17)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Period Start:"
        '
        'PeriodEnd
        '
        Me.PeriodEnd.CustomFormat = "yyyy-MM-dd"
        Me.PeriodEnd.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.PeriodEnd.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.PeriodEnd.Location = New System.Drawing.Point(205, 105)
        Me.PeriodEnd.Name = "PeriodEnd"
        Me.PeriodEnd.Size = New System.Drawing.Size(181, 20)
        Me.PeriodEnd.TabIndex = 12
        '
        'PeriodStart
        '
        Me.PeriodStart.CustomFormat = "yyyy-MM-dd"
        Me.PeriodStart.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.PeriodStart.Location = New System.Drawing.Point(205, 39)
        Me.PeriodStart.Name = "PeriodStart"
        Me.PeriodStart.Size = New System.Drawing.Size(181, 20)
        Me.PeriodStart.TabIndex = 11
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.Window
        Me.Label5.Location = New System.Drawing.Point(295, 156)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 17)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Trainee Name:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Window
        Me.Label4.Location = New System.Drawing.Point(77, 156)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 17)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Trainee ID:"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(-4, -4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(659, 339)
        Me.DataGridView1.TabIndex = 46
        '
        'back_bttn
        '
        Me.back_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.back_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.back_bttn.Image = CType(resources.GetObject("back_bttn.Image"), System.Drawing.Image)
        Me.back_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.back_bttn.Location = New System.Drawing.Point(31, 351)
        Me.back_bttn.Name = "back_bttn"
        Me.back_bttn.Size = New System.Drawing.Size(65, 33)
        Me.back_bttn.TabIndex = 50
        Me.back_bttn.Text = "Back"
        Me.back_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.back_bttn.UseVisualStyleBackColor = False
        '
        'insert_bttn
        '
        Me.insert_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.insert_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.insert_bttn.Image = CType(resources.GetObject("insert_bttn.Image"), System.Drawing.Image)
        Me.insert_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.insert_bttn.Location = New System.Drawing.Point(223, 351)
        Me.insert_bttn.Name = "insert_bttn"
        Me.insert_bttn.Size = New System.Drawing.Size(65, 33)
        Me.insert_bttn.TabIndex = 49
        Me.insert_bttn.Text = "Insert"
        Me.insert_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.insert_bttn.UseVisualStyleBackColor = False
        '
        'payslip_bttn
        '
        Me.payslip_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.payslip_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.payslip_bttn.Image = CType(resources.GetObject("payslip_bttn.Image"), System.Drawing.Image)
        Me.payslip_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.payslip_bttn.Location = New System.Drawing.Point(521, 430)
        Me.payslip_bttn.Name = "payslip_bttn"
        Me.payslip_bttn.Size = New System.Drawing.Size(65, 33)
        Me.payslip_bttn.TabIndex = 51
        Me.payslip_bttn.Text = "Payslip"
        Me.payslip_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.payslip_bttn.UseVisualStyleBackColor = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.Window
        Me.Label6.Location = New System.Drawing.Point(171, 233)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 17)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "No. of Days:"
        '
        'allwnc
        '
        Me.allwnc.Location = New System.Drawing.Point(263, 232)
        Me.allwnc.Name = "allwnc"
        Me.allwnc.Size = New System.Drawing.Size(123, 20)
        Me.allwnc.TabIndex = 52
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Window
        Me.Label7.Location = New System.Drawing.Point(146, 282)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(111, 17)
        Me.Label7.TabIndex = 55
        Me.Label7.Text = "Total Allowance:"
        '
        'Total
        '
        Me.Total.Location = New System.Drawing.Point(263, 281)
        Me.Total.Name = "Total"
        Me.Total.ReadOnly = True
        Me.Total.Size = New System.Drawing.Size(123, 20)
        Me.Total.TabIndex = 54
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TabControl1.Location = New System.Drawing.Point(518, 64)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(659, 357)
        Me.TabControl1.TabIndex = 56
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.DataGridView1)
        Me.TabPage1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(651, 331)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "DATABASE"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TextBox1)
        Me.TabPage2.Cursor = System.Windows.Forms.Cursors.Default
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(651, 331)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "PRINT PREVIEW"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.TextBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox1.Location = New System.Drawing.Point(3, 3)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.Size = New System.Drawing.Size(645, 325)
        Me.TextBox1.TabIndex = 0
        '
        'update_bttn
        '
        Me.update_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.update_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.update_bttn.Image = CType(resources.GetObject("update_bttn.Image"), System.Drawing.Image)
        Me.update_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.update_bttn.Location = New System.Drawing.Point(318, 351)
        Me.update_bttn.Name = "update_bttn"
        Me.update_bttn.Size = New System.Drawing.Size(65, 33)
        Me.update_bttn.TabIndex = 73
        Me.update_bttn.Text = "Update"
        Me.update_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.update_bttn.UseVisualStyleBackColor = False
        '
        'delete_bttn
        '
        Me.delete_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.delete_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.delete_bttn.Image = CType(resources.GetObject("delete_bttn.Image"), System.Drawing.Image)
        Me.delete_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.delete_bttn.Location = New System.Drawing.Point(410, 351)
        Me.delete_bttn.Name = "delete_bttn"
        Me.delete_bttn.Size = New System.Drawing.Size(65, 33)
        Me.delete_bttn.TabIndex = 74
        Me.delete_bttn.Text = "Delete"
        Me.delete_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.delete_bttn.UseVisualStyleBackColor = False
        '
        'clear_bttn
        '
        Me.clear_bttn.BackColor = System.Drawing.Color.DarkGray
        Me.clear_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.clear_bttn.Image = CType(resources.GetObject("clear_bttn.Image"), System.Drawing.Image)
        Me.clear_bttn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.clear_bttn.Location = New System.Drawing.Point(127, 351)
        Me.clear_bttn.Name = "clear_bttn"
        Me.clear_bttn.Size = New System.Drawing.Size(65, 33)
        Me.clear_bttn.TabIndex = 75
        Me.clear_bttn.Text = "Clear"
        Me.clear_bttn.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.clear_bttn.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-8, -9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(147, 134)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 76
        Me.PictureBox1.TabStop = False
        '
        'PayTrainee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImage = Global.BOC.My.Resources.Resources._1272AD4B_2385_42EC_AD32_3D7BA3438412
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1194, 520)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.clear_bttn)
        Me.Controls.Add(Me.delete_bttn)
        Me.Controls.Add(Me.update_bttn)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Total)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.allwnc)
        Me.Controls.Add(Me.payslip_bttn)
        Me.Controls.Add(Me.back_bttn)
        Me.Controls.Add(Me.insert_bttn)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Tname)
        Me.Controls.Add(Me.Tid)
        Me.Controls.Add(Me.payrollid)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PeriodEnd)
        Me.Controls.Add(Me.PeriodStart)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PayTrainee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Payroll"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Tname As TextBox
    Friend WithEvents Tid As TextBox
    Friend WithEvents payrollid As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents PeriodEnd As DateTimePicker
    Friend WithEvents PeriodStart As DateTimePicker
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents back_bttn As Button
    Friend WithEvents insert_bttn As Button
    Friend WithEvents payslip_bttn As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents allwnc As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Total As TextBox
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents update_bttn As Button
    Friend WithEvents delete_bttn As Button
    Friend WithEvents clear_bttn As Button
    Friend WithEvents PictureBox1 As PictureBox
End Class
