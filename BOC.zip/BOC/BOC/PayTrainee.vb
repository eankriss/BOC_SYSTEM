﻿Imports MySql.Data.MySqlClient

Public Class PayTrainee

    Dim con As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim dr As MySqlDataReader


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles insert_bttn.Click

        Dim con As New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim dr As MySqlDataReader
        con.ConnectionString = "server=localhost;username=root;password=;Persist Security Info=True;database=boc;Convert Zero Datetime=True"


        Try
            con.Open()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from payrolltrainee where Trainee_Id='" & Tid.Text & "'"
            dr = cmd.ExecuteReader

            If dr.HasRows Then

                MsgBox("Trainee Id Already Registered", MsgBoxStyle.Critical)
                con.Close()

            Else

                con.Close()
                con.Open()
                cmd.CommandText = "INSERT INTO payrolltrainee (`Trainee_Id`, `Trainee_Name`, `PeriodStart`, `PeriodEnd`, `No_of_Days`, `Total_allowance`,`Payroll_id`) VALUES
                ('" & Tid.Text & "', '" & Tname.Text & "','" & PeriodStart.Value & "','" & PeriodEnd.Value & "', '" & allwnc.Text & "', '" & Total.Text & "', '" & payrollid.Text & "'  )"

                If (Tname.Text = "" Or PeriodStart.Text = "" Or PeriodEnd.Text = "" Or allwnc.Text = "" Or Total.Text = "") Then

                    MessageBox.Show("Please enter the details")

                Else

                    cmd.ExecuteNonQuery()
                    MsgBox("Successfully Save.", MsgBoxStyle.Information, "Save")

                    PeriodStart.Value = Today
                    PeriodEnd.Value = Today
                    Tid.Clear()
                    Tname.Clear()
                    allwnc.Text = "0"
                    Total.Text = "0"
                    payrollid.Text = ""

                End If

            End If

            con.Close()

        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try

        Dim str As String

        Try

            str = "SELECT * FROM payrolltrainee"

            con.Open()

            Dim da As New MySqlDataAdapter(str, con)

            Dim dt As New DataTable

            da.Fill(dt)

            DataGridView1.DataSource = dt

            con.Close()


        Catch ex As Exception

            MsgBox(ex.Message)

            con.Close()

        End Try

    End Sub


    Dim ExitYN As System.Windows.Forms.DialogResult

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles back_bttn.Click

        addtrain2.Show()
        Me.Hide()

        PeriodStart.Value = Today
        PeriodEnd.Value = Today
        Tid.Clear()
        Tname.Clear()
        allwnc.Text = "0"
        Total.Text = "0"
        payrollid.Text = ""

    End Sub

    Private Sub allwnc_TextChanged(sender As Object, e As EventArgs) Handles allwnc.TextChanged

        Total.Text = Val(allwnc.Text) * 150

    End Sub

    Private Sub PeriodStart_ValueChanged(sender As Object, e As EventArgs) Handles PeriodStart.ValueChanged

        con.ConnectionString = "server=localhost;username=root;password=;Persist Security Info=True;database=boc;Convert Zero Datetime=True"


        If PeriodStart.Value.Day <= 15 Then

            Dim diffdate As Integer

            diffdate = 15 - PeriodStart.Value.Day
            PeriodEnd.Value = (PeriodStart.Value.AddDays(diffdate))

            payrollid.Text = "BOC" & PeriodEnd.Value.Month & PeriodEnd.Value.Day & PeriodEnd.Value.Year

        Else

            Dim diffdate As Integer

            diffdate = 30 - PeriodStart.Value.Day
            PeriodEnd.Value = (PeriodStart.Value.AddDays(diffdate))

            payrollid.Text = "BOC" & PeriodEnd.Value.Month & PeriodEnd.Value.Day & PeriodEnd.Value.Year

        End If

    End Sub

    Private Sub PayTrainee_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        con = New MySqlConnection
        cmd = con.CreateCommand()
        con.ConnectionString = "server=localhost;username=root;password=;database=boc"

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from payrolltrainee"
        con.Open()
        con.Close()

        Dim dt As New DataTable()
        Dim mydata As New MySqlDataAdapter(cmd)

        mydata.Fill(dt)
        DataGridView1.DataSource = dt

        allwnc.Text = "0"
        Total.Text = "0"

    End Sub

    Private Sub PayTrainee_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim g As DialogResult

        g = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If g = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

    Private Sub Tid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Tid.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub allwnc_KeyPress(sender As Object, e As KeyPressEventArgs) Handles allwnc.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub


    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles payslip_bttn.Click

        If (Tid.Text = "" Or Tname.Text = "" Or PeriodStart.Text = "" Or PeriodEnd.Text = "" Or allwnc.Text = "" Or Total.Text = "") Then

            MessageBox.Show("Please select details to print")

        Else

            TextBox1.Text = ""
            TextBox1.AppendText("" + vbNewLine)

            TextBox1.AppendText(vbTab + vbTab + vbTab + vbTab + vbTab & "BLACK OLIVES CAFE" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + vbTab + vbTab + vbTab & "McArthur Highway, Sampaloc, Apalit, Pampanga" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + vbTab + vbTab + vbTab + vbTab & "CONTACT No.: 09157183388" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)

            TextBox1.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "Period Start: " + vbTab & PeriodStart.Value + vbTab + vbTab + vbTab + vbTab + "Payroll ID: " + vbTab & payrollid.Text + vbTab + vbTab + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "Period End: " + vbTab & PeriodEnd.Value + vbTab + vbTab + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)

            TextBox1.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "Trainee ID: " + vbTab & Tid.Text + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "Trainee Name: " + vbTab & Tname.Text + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)

            TextBox1.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "No. of Days: " + vbTab & allwnc.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Total Allowance: " + vbTab & Total.Text + vbTab + vbTab + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)

            TextBox1.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "Date: " + vbTab & Format(Now, "MMMM dd, yyyy") & vbTab + vbTab + vbTab + vbTab + vbTab & "Time: " + vbTab & Format(Now, "hh:mm:ss tt") + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText(vbTab + "Received by:" + "   ___________________" + vbNewLine)
            TextBox1.AppendText(vbTab + vbTab + vbTab + Tname.Text + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)
            TextBox1.AppendText("" + vbNewLine)

            TextBox1.AppendText(vbTab + vbTab + vbTab + PictureBox1.Text + vbNewLine)

            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
            PrintPreviewDialog1.ShowDialog()

        End If

    End Sub

    Private Sub Tname_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Tname.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 65 Or Asc(e.KeyChar) > 90 And Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then

                e.Handled = True
                MessageBox.Show("You can only input letters in this field")

            End If

        End If

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        ''e.Graphics.DrawString(TextBox1.Text, Font, Brushes.Black, 140, 140)
        e.Graphics.DrawString(TextBox1.Text, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, 140, 140)
        e.Graphics.DrawImage(Me.PictureBox1.Image, 120, 120, PictureBox1.Width - 15, PictureBox1.Height - 25)

    End Sub

    Private Sub clear_bttn_Click(sender As Object, e As EventArgs) Handles clear_bttn.Click

        PeriodStart.Value = Today
        PeriodEnd.Value = Today
        Tid.Clear()
        Tname.Clear()
        allwnc.Text = "0"
        Total.Text = "0"
        payrollid.Text = ""


    End Sub

    Private Sub update_bttn_Click(sender As Object, e As EventArgs) Handles update_bttn.Click

        If (Tid.Text = "" Or Tname.Text = "" Or PeriodStart.Text = "" Or PeriodEnd.Text = "" Or allwnc.Text = "" Or Total.Text = "") Then

            MessageBox.Show("Please enter the complete details to update")

        Else

            con = New MySqlConnection
            con.ConnectionString = "server=localhost;username=root;password=;Persist Security Info=True;database=boc;Convert Zero Datetime=True"
            Dim reader As MySqlDataReader
            Try

                con.Open()
                Dim query As String
                query = "update payrolltrainee set Trainee_ID='" & Tid.Text & "', Trainee_Name='" & Tname.Text & "', PeriodStart='" & PeriodStart.Value & "', PeriodEnd='" & PeriodEnd.Value & "', No_of_Days='" & allwnc.Text & "' , Total_allowance='" & Total.Text & "' , Payroll_id='" & payrollid.Text & "' "
                cmd = New MySqlCommand(query, con)
                reader = cmd.ExecuteReader()

                MessageBox.Show("Data Save Successfully!")
                con.Close()

                Tid.Clear()
                Tname.Clear()
                PeriodStart.Value = Today
                PeriodEnd.Value = Today
                allwnc.Text = "0"
                Total.Text = "0"
                payrollid.Text = ""

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Dim str As String

            Try

                str = "SELECT * FROM payrolltrainee"

                con.Open()

                Dim da As New MySqlDataAdapter(str, con)

                Dim dt As New DataTable

                da.Fill(dt)

                DataGridView1.DataSource = dt

                con.Close()


            Catch ex As Exception

                MsgBox(ex.Message)

                con.Close()

            End Try

        End If

    End Sub

    Private Sub delete_bttn_Click(sender As Object, e As EventArgs) Handles delete_bttn.Click

        If Tid.Text = "" Then

            MessageBox.Show("Please input a Trainee ID to delete a data")

        Else

            con = New MySqlConnection
            con.ConnectionString = "server=localhost; username=root; password=; database=boc"
            Dim reader As MySqlDataReader

            Try

                con.Open()
                Dim query As String
                query = "Delete from payrolltrainee where Trainee_Id='" & Tid.Text & "' "
                cmd = New MySqlCommand(query, con)
                reader = cmd.ExecuteReader()

                MessageBox.Show("Data Deleted Successfully!")
                con.Close()

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Try

                con.Open()
                Dim querryy As String
                querryy = "Alter Table payrolltrainee AUTO_INCREMENT = 1"
                cmd = New MySqlCommand(querryy, con)
                reader = cmd.ExecuteReader()

                con.Close()

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Dim str As String

            Try

                str = "SELECT * FROM payrolltrainee"

                con.Open()

                Dim da As New MySqlDataAdapter(str, con)

                Dim dt As New DataTable

                da.Fill(dt)

                DataGridView1.DataSource = dt

                con.Close()


            Catch ex As Exception

                MsgBox(ex.Message)

                con.Close()

            End Try

            PeriodStart.Value = Today
            PeriodEnd.Value = Today
            Tid.Clear()
            Tname.Clear()
            allwnc.Text = "0"
            Total.Text = "0"
            payrollid.Text = ""

        End If

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        Try

            If e.RowIndex >= 0 Then

                Dim row As DataGridViewRow
                row = Me.DataGridView1.Rows(e.RowIndex)

                Tid.Text = row.Cells("Trainee_Id").Value.ToString
                Tname.Text = row.Cells("Trainee_Name").Value.ToString
                PeriodStart.Value = row.Cells("PeriodStart").Value.ToString
                PeriodEnd.Value = row.Cells("PeriodEnd").Value.ToString
                allwnc.Text = row.Cells("No_of_Days").Value.ToString
                Total.Text = row.Cells("Total_allowance").Value.ToString
                payrollid.Text = row.Cells("Payroll_id").Value.ToString

            End If

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub allwnc_Enter(sender As Object, e As EventArgs) Handles allwnc.Enter

        If allwnc.Text = "0" Then

            allwnc.Text = ""
            allwnc.ForeColor = Color.Black

        End If

    End Sub

    Private Sub allwnc_Leave(sender As Object, e As EventArgs) Handles allwnc.Leave

        If allwnc.Text = "" Then

            allwnc.Text = "0"
            allwnc.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Total_Enter(sender As Object, e As EventArgs) Handles Total.Enter

        If Total.Text = "0" Then

            Total.Text = ""
            Total.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Total_Leave(sender As Object, e As EventArgs) Handles Total.Leave

        If Total.Text = "" Then

            Total.Text = "0"
            Total.ForeColor = Color.Black

        End If

    End Sub

End Class