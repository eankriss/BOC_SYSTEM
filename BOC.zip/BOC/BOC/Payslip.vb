﻿Imports System.ComponentModel
Imports MySql.Data.MySqlClient

Public Class ChangePass

    Dim con As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim read As MySqlDataReader

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If TextBox1.Text = "" And TextBox2.Text = "" And TextBox3.Text = "" Then

            MessageBox.Show("Please complete the credentials!")

            ErrorProvider1.SetError(TextBox1, "Old Password is required")
            ErrorProvider2.SetError(TextBox2, "New Password is required")
            ErrorProvider3.SetError(TextBox3, "Confirm Password is required")

        ElseIf TextBox2.Text = "" And TextBox3.Text = "" Then

            MessageBox.Show("Please complete the credentials!")

            ErrorProvider2.SetError(TextBox2, "New Password is required")
            ErrorProvider3.SetError(TextBox3, "Confirm Password is required")

        ElseIf TextBox1.Text = "" And TextBox3.Text = "" Then

            MessageBox.Show("Please complete the credentials!")

            ErrorProvider1.SetError(TextBox1, "Old Password is required")
            ErrorProvider3.SetError(TextBox3, "Confirm Password is required")

        ElseIf TextBox1.Text = "" And TextBox2.Text = "" Then

            MessageBox.Show("Please complete the credentials!")

            ErrorProvider1.SetError(TextBox1, "Old Password is required")
            ErrorProvider2.SetError(TextBox2, "New Password is required")

        ElseIf TextBox2.Text <> TextBox3.Text Then

            MessageBox.Show("Password did not match")

            ErrorProvider2.SetError(TextBox2, "Password did not match")
            ErrorProvider3.SetError(TextBox3, "Password did not match")

        ElseIf TextBox1.Text = "" Then

            MessageBox.Show("Please complete the credentials!")

            ErrorProvider1.SetError(TextBox1, "Old Password is required")

        Else

            Dim con As New MySqlConnection("server=localhost;username=root;password=;database=boc")
            Dim cmd As New MySqlCommand
            Dim read As MySqlDataReader

            con.Open()
            cmd.Connection = con
            cmd.CommandText = "select * from account where Password='" & TextBox1.Text & "' "

            read = cmd.ExecuteReader
            If read.HasRows Then

                Change_Pass()

            Else

                MessageBox.Show("Old Password not recognize by the database")

            End If

            con.Close()
        End If
    End Sub

    Private Sub Change_Pass()

        Dim con As New MySqlConnection("server=localhost;username=root;password=;database=boc")
        Dim cmd As New MySqlCommand

        con.Open()
        cmd.Connection = con
        cmd.CommandText = "UPDATE `account` SET `password` = '" & TextBox2.Text & "' WHERE `account`.`password` = '" & TextBox1.Text & "'"
        '' "update account set password='" & TextBox2.Text & "' And '" & TextBox3.Text & "' where password='" & TextBox1.Text & "'  "

        cmd.ExecuteNonQuery()
        MessageBox.Show("Password has been changed succesfully.")

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()

        con.Close()

    End Sub

    Private Sub Payslip_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Dim d As DialogResult

        d = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If d = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

    Private Sub back_bttn_Click(sender As Object, e As EventArgs) Handles back_bttn.Click

        EmpTrain.Show()
        Me.Hide()

        Me.ErrorProvider1.Clear()
        Me.ErrorProvider2.Clear()
        Me.ErrorProvider3.Clear()

        If CheckBox1.Checked = True Or CheckBox2.Checked = True Or CheckBox3.Checked = True Then

            CheckBox1.Checked = False
            CheckBox2.Checked = False
            CheckBox3.Checked = False

        End If

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then

            TextBox1.UseSystemPasswordChar = False

        Else

            TextBox1.UseSystemPasswordChar = True

        End If

    End Sub

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then

            TextBox2.UseSystemPasswordChar = False

        Else

            TextBox2.UseSystemPasswordChar = True

        End If

    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then

            TextBox3.UseSystemPasswordChar = False

        Else

            TextBox3.UseSystemPasswordChar = True

        End If

    End Sub


    Private Sub TextBox1_Validating(sender As Object, e As CancelEventArgs) Handles TextBox1.Validating

        If String.IsNullOrEmpty(TextBox1.Text.Trim) Then

            ErrorProvider1.SetError(TextBox1, "Old Password is required")

        Else

            ErrorProvider1.SetError(TextBox1, String.Empty)

        End If

    End Sub

    Private Sub TextBox2_Validating(sender As Object, e As CancelEventArgs) Handles TextBox2.Validating

        If String.IsNullOrEmpty(TextBox2.Text.Trim) Then

            ErrorProvider2.SetError(TextBox2, "New Password is required")

        Else

            ErrorProvider2.SetError(TextBox2, String.Empty)

        End If

    End Sub

    Private Sub TextBox3_Validating(sender As Object, e As CancelEventArgs) Handles TextBox3.Validating

        If String.IsNullOrEmpty(TextBox3.Text.Trim) Then

            ErrorProvider3.SetError(TextBox3, "Confirm Password is required")

        Else

            ErrorProvider3.SetError(TextBox3, String.Empty)

        End If

    End Sub

End Class