﻿Public Class addtrain2
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Addtrainee.Show()

        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PayTrainee.Show()
        Me.Hide()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        EmpTrain.Show()
        Me.Hide()

    End Sub

    Private Sub addtrain2_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Dim d As DialogResult

        d = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If d = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

End Class