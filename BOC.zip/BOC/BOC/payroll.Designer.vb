﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class payroll
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(payroll))
        Me.DateTimePicker1_PERIOD_START = New System.Windows.Forms.DateTimePicker()
        Me.DateTimePicker2_PERIOD_END = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.payrollid = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.OT = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.otherloan = New System.Windows.Forms.TextBox()
        Me.phloan = New System.Windows.Forms.TextBox()
        Me.sssloan = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.philh = New System.Windows.Forms.TextBox()
        Me.pagibig = New System.Windows.Forms.TextBox()
        Me.sss = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.netpay = New System.Windows.Forms.TextBox()
        Me.totaldeduc = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.bttn_insert = New System.Windows.Forms.Button()
        Me.bttn_payslip = New System.Windows.Forms.Button()
        Me.bttn_back = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.totalsal = New System.Windows.Forms.TextBox()
        Me.basicpay = New System.Windows.Forms.TextBox()
        Me.hrworked = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.otpay = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Tardiness = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.absent = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.special = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Reg = New System.Windows.Forms.TextBox()
        Me.Regular = New System.Windows.Forms.Label()
        Me.nonworking = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.bttn_delete = New System.Windows.Forms.Button()
        Me.bttn_update = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.bttn_clear = New System.Windows.Forms.Button()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DateTimePicker1_PERIOD_START
        '
        Me.DateTimePicker1_PERIOD_START.CustomFormat = "yyyy-MM-dd"
        Me.DateTimePicker1_PERIOD_START.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker1_PERIOD_START.Location = New System.Drawing.Point(152, 51)
        Me.DateTimePicker1_PERIOD_START.Name = "DateTimePicker1_PERIOD_START"
        Me.DateTimePicker1_PERIOD_START.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1_PERIOD_START.TabIndex = 0
        '
        'DateTimePicker2_PERIOD_END
        '
        Me.DateTimePicker2_PERIOD_END.CustomFormat = "yyyy-MM-dd"
        Me.DateTimePicker2_PERIOD_END.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DateTimePicker2_PERIOD_END.Location = New System.Drawing.Point(372, 51)
        Me.DateTimePicker2_PERIOD_END.Name = "DateTimePicker2_PERIOD_END"
        Me.DateTimePicker2_PERIOD_END.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker2_PERIOD_END.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Window
        Me.Label1.Location = New System.Drawing.Point(149, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 17)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Period Start:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Window
        Me.Label2.Location = New System.Drawing.Point(369, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(93, 17)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Period End:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Window
        Me.Label3.Location = New System.Drawing.Point(682, 31)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 17)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Payroll ID:"
        '
        'payrollid
        '
        Me.payrollid.AutoSize = True
        Me.payrollid.BackColor = System.Drawing.Color.Transparent
        Me.payrollid.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.payrollid.ForeColor = System.Drawing.SystemColors.Window
        Me.payrollid.Location = New System.Drawing.Point(772, 31)
        Me.payrollid.Name = "payrollid"
        Me.payrollid.Size = New System.Drawing.Size(0, 17)
        Me.payrollid.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Window
        Me.Label4.Location = New System.Drawing.Point(149, 88)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(103, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Employee ID:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.Window
        Me.Label5.Location = New System.Drawing.Point(369, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(129, 17)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Employee Name:"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(152, 108)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(200, 20)
        Me.TextBox1.TabIndex = 8
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(372, 108)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(200, 20)
        Me.TextBox2.TabIndex = 9
        '
        'OT
        '
        Me.OT.ForeColor = System.Drawing.SystemColors.WindowText
        Me.OT.Location = New System.Drawing.Point(190, 190)
        Me.OT.Name = "OT"
        Me.OT.Size = New System.Drawing.Size(92, 20)
        Me.OT.TabIndex = 18
        Me.OT.Text = "0"
        Me.OT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.Window
        Me.Label9.Location = New System.Drawing.Point(114, 193)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 17)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Overtime "
        '
        'otherloan
        '
        Me.otherloan.Location = New System.Drawing.Point(568, 493)
        Me.otherloan.Name = "otherloan"
        Me.otherloan.Size = New System.Drawing.Size(92, 20)
        Me.otherloan.TabIndex = 40
        Me.otherloan.Text = "0"
        Me.otherloan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'phloan
        '
        Me.phloan.Location = New System.Drawing.Point(568, 444)
        Me.phloan.Name = "phloan"
        Me.phloan.Size = New System.Drawing.Size(92, 20)
        Me.phloan.TabIndex = 39
        Me.phloan.Text = "0"
        Me.phloan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sssloan
        '
        Me.sssloan.Location = New System.Drawing.Point(568, 398)
        Me.sssloan.Name = "sssloan"
        Me.sssloan.Size = New System.Drawing.Size(92, 20)
        Me.sssloan.TabIndex = 38
        Me.sssloan.Text = "0"
        Me.sssloan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.Window
        Me.Label15.Location = New System.Drawing.Point(474, 496)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(91, 16)
        Me.Label15.TabIndex = 37
        Me.Label15.Text = "Other Loans"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.Window
        Me.Label14.Location = New System.Drawing.Point(437, 446)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(130, 16)
        Me.Label14.TabIndex = 36
        Me.Label14.Text = "Phil-Health Loans"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.Window
        Me.Label13.Location = New System.Drawing.Point(481, 398)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(84, 16)
        Me.Label13.TabIndex = 35
        Me.Label13.Text = "SSS Loans"
        '
        'philh
        '
        Me.philh.Location = New System.Drawing.Point(190, 488)
        Me.philh.Name = "philh"
        Me.philh.ReadOnly = True
        Me.philh.Size = New System.Drawing.Size(92, 20)
        Me.philh.TabIndex = 34
        Me.philh.Text = "0"
        Me.philh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'pagibig
        '
        Me.pagibig.Location = New System.Drawing.Point(190, 439)
        Me.pagibig.Name = "pagibig"
        Me.pagibig.ReadOnly = True
        Me.pagibig.Size = New System.Drawing.Size(92, 20)
        Me.pagibig.TabIndex = 33
        Me.pagibig.Text = "0"
        Me.pagibig.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'sss
        '
        Me.sss.Location = New System.Drawing.Point(190, 394)
        Me.sss.Name = "sss"
        Me.sss.ReadOnly = True
        Me.sss.Size = New System.Drawing.Size(92, 20)
        Me.sss.TabIndex = 32
        Me.sss.Text = "0"
        Me.sss.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.Window
        Me.Label12.Location = New System.Drawing.Point(105, 490)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(84, 16)
        Me.Label12.TabIndex = 31
        Me.Label12.Text = "Phil-Health"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.Window
        Me.Label11.Location = New System.Drawing.Point(120, 441)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(67, 16)
        Me.Label11.TabIndex = 30
        Me.Label11.Text = "Pag-Ibig"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.Window
        Me.Label10.Location = New System.Drawing.Point(150, 396)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 16)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "SSS"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.Window
        Me.Label16.Location = New System.Drawing.Point(73, 350)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(209, 25)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "LESS DEDUCTION"
        '
        'netpay
        '
        Me.netpay.Location = New System.Drawing.Point(568, 591)
        Me.netpay.Name = "netpay"
        Me.netpay.ReadOnly = True
        Me.netpay.Size = New System.Drawing.Size(92, 20)
        Me.netpay.TabIndex = 44
        Me.netpay.Text = "0"
        Me.netpay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'totaldeduc
        '
        Me.totaldeduc.Location = New System.Drawing.Point(190, 589)
        Me.totaldeduc.Name = "totaldeduc"
        Me.totaldeduc.ReadOnly = True
        Me.totaldeduc.Size = New System.Drawing.Size(92, 20)
        Me.totaldeduc.TabIndex = 43
        Me.totaldeduc.Text = "0"
        Me.totaldeduc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.BackColor = System.Drawing.Color.Transparent
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.Window
        Me.Label17.Location = New System.Drawing.Point(407, 592)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(160, 16)
        Me.Label17.TabIndex = 42
        Me.Label17.Text = "Net Pay for the Period"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.BackColor = System.Drawing.Color.Transparent
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.Window
        Me.Label18.Location = New System.Drawing.Point(70, 589)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(118, 16)
        Me.Label18.TabIndex = 41
        Me.Label18.Text = "Total Deduction"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(685, 80)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(656, 335)
        Me.DataGridView1.TabIndex = 45
        '
        'bttn_insert
        '
        Me.bttn_insert.BackColor = System.Drawing.Color.DarkGray
        Me.bttn_insert.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttn_insert.Image = CType(resources.GetObject("bttn_insert.Image"), System.Drawing.Image)
        Me.bttn_insert.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bttn_insert.Location = New System.Drawing.Point(357, 639)
        Me.bttn_insert.Name = "bttn_insert"
        Me.bttn_insert.Size = New System.Drawing.Size(65, 33)
        Me.bttn_insert.TabIndex = 46
        Me.bttn_insert.Text = "Insert"
        Me.bttn_insert.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.bttn_insert.UseVisualStyleBackColor = False
        '
        'bttn_payslip
        '
        Me.bttn_payslip.BackColor = System.Drawing.Color.DarkGray
        Me.bttn_payslip.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttn_payslip.Image = CType(resources.GetObject("bttn_payslip.Image"), System.Drawing.Image)
        Me.bttn_payslip.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bttn_payslip.Location = New System.Drawing.Point(685, 639)
        Me.bttn_payslip.Name = "bttn_payslip"
        Me.bttn_payslip.Size = New System.Drawing.Size(65, 33)
        Me.bttn_payslip.TabIndex = 47
        Me.bttn_payslip.Text = "Payslip"
        Me.bttn_payslip.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.bttn_payslip.UseVisualStyleBackColor = False
        '
        'bttn_back
        '
        Me.bttn_back.BackColor = System.Drawing.Color.DarkGray
        Me.bttn_back.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttn_back.Image = CType(resources.GetObject("bttn_back.Image"), System.Drawing.Image)
        Me.bttn_back.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bttn_back.Location = New System.Drawing.Point(153, 639)
        Me.bttn_back.Name = "bttn_back"
        Me.bttn_back.Size = New System.Drawing.Size(65, 33)
        Me.bttn_back.TabIndex = 48
        Me.bttn_back.Text = "Back"
        Me.bttn_back.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.bttn_back.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.Window
        Me.Label8.Location = New System.Drawing.Point(474, 275)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(93, 16)
        Me.Label8.TabIndex = 52
        Me.Label8.Text = "Total Salary"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Window
        Me.Label7.Location = New System.Drawing.Point(487, 150)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(78, 16)
        Me.Label7.TabIndex = 51
        Me.Label7.Text = "Basic Pay"
        '
        'totalsal
        '
        Me.totalsal.Location = New System.Drawing.Point(568, 273)
        Me.totalsal.Name = "totalsal"
        Me.totalsal.ReadOnly = True
        Me.totalsal.Size = New System.Drawing.Size(92, 20)
        Me.totalsal.TabIndex = 50
        Me.totalsal.Text = "0"
        Me.totalsal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'basicpay
        '
        Me.basicpay.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.basicpay.Location = New System.Drawing.Point(568, 148)
        Me.basicpay.Name = "basicpay"
        Me.basicpay.ReadOnly = True
        Me.basicpay.Size = New System.Drawing.Size(92, 20)
        Me.basicpay.TabIndex = 49
        Me.basicpay.Text = "0"
        Me.basicpay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'hrworked
        '
        Me.hrworked.ForeColor = System.Drawing.SystemColors.WindowText
        Me.hrworked.Location = New System.Drawing.Point(190, 147)
        Me.hrworked.Name = "hrworked"
        Me.hrworked.Size = New System.Drawing.Size(92, 20)
        Me.hrworked.TabIndex = 54
        Me.hrworked.Text = "0"
        Me.hrworked.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.Window
        Me.Label6.Location = New System.Drawing.Point(35, 152)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(152, 16)
        Me.Label6.TabIndex = 53
        Me.Label6.Text = "No. of Hours Worked"
        '
        'otpay
        '
        Me.otpay.Location = New System.Drawing.Point(568, 191)
        Me.otpay.Name = "otpay"
        Me.otpay.ReadOnly = True
        Me.otpay.Size = New System.Drawing.Size(92, 20)
        Me.otpay.TabIndex = 56
        Me.otpay.Text = "0"
        Me.otpay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.Window
        Me.Label19.Location = New System.Drawing.Point(457, 191)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(105, 17)
        Me.Label19.TabIndex = 55
        Me.Label19.Text = "Overtime Pay"
        '
        'Tardiness
        '
        Me.Tardiness.Location = New System.Drawing.Point(190, 541)
        Me.Tardiness.Name = "Tardiness"
        Me.Tardiness.Size = New System.Drawing.Size(92, 20)
        Me.Tardiness.TabIndex = 58
        Me.Tardiness.Text = "0"
        Me.Tardiness.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.Window
        Me.Label20.Location = New System.Drawing.Point(104, 543)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(80, 17)
        Me.Label20.TabIndex = 57
        Me.Label20.Text = "Tardiness"
        '
        'absent
        '
        Me.absent.Location = New System.Drawing.Point(568, 546)
        Me.absent.Name = "absent"
        Me.absent.Size = New System.Drawing.Size(92, 20)
        Me.absent.TabIndex = 60
        Me.absent.Text = "0"
        Me.absent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.Window
        Me.Label21.Location = New System.Drawing.Point(504, 549)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(58, 17)
        Me.Label21.TabIndex = 59
        Me.Label21.Text = "Absent"
        '
        'special
        '
        Me.special.ForeColor = System.Drawing.SystemColors.WindowText
        Me.special.Location = New System.Drawing.Point(190, 231)
        Me.special.Name = "special"
        Me.special.Size = New System.Drawing.Size(92, 20)
        Me.special.TabIndex = 62
        Me.special.Text = "0"
        Me.special.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.Window
        Me.Label22.Location = New System.Drawing.Point(48, 234)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(141, 17)
        Me.Label22.TabIndex = 61
        Me.Label22.Text = "S.Working Holiday"
        '
        'Reg
        '
        Me.Reg.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Reg.Location = New System.Drawing.Point(568, 230)
        Me.Reg.Name = "Reg"
        Me.Reg.Size = New System.Drawing.Size(92, 20)
        Me.Reg.TabIndex = 64
        Me.Reg.Text = "0"
        Me.Reg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Regular
        '
        Me.Regular.AutoSize = True
        Me.Regular.BackColor = System.Drawing.Color.Transparent
        Me.Regular.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Regular.ForeColor = System.Drawing.SystemColors.Window
        Me.Regular.Location = New System.Drawing.Point(442, 233)
        Me.Regular.Name = "Regular"
        Me.Regular.Size = New System.Drawing.Size(124, 17)
        Me.Regular.TabIndex = 63
        Me.Regular.Text = "Regular Holiday"
        '
        'nonworking
        '
        Me.nonworking.ForeColor = System.Drawing.SystemColors.WindowText
        Me.nonworking.Location = New System.Drawing.Point(190, 269)
        Me.nonworking.Name = "nonworking"
        Me.nonworking.Size = New System.Drawing.Size(92, 20)
        Me.nonworking.TabIndex = 66
        Me.nonworking.Text = "0"
        Me.nonworking.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.Window
        Me.Label24.Location = New System.Drawing.Point(12, 272)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(181, 17)
        Me.Label24.TabIndex = 65
        Me.Label24.Text = "S.Non-Working Holiday "
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.TabControl1.Location = New System.Drawing.Point(685, 60)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(656, 354)
        Me.TabControl1.TabIndex = 67
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.DataGridView2)
        Me.TabPage1.Cursor = System.Windows.Forms.Cursors.Default
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(648, 328)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "DATABASE"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.BackgroundColor = System.Drawing.Color.White
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(-1, -1)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.Size = New System.Drawing.Size(652, 336)
        Me.DataGridView2.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TextBox3)
        Me.TabPage2.Cursor = System.Windows.Forms.Cursors.Default
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(648, 328)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "PRINT PREVIEW"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.TextBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(3, 3)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox3.Size = New System.Drawing.Size(642, 322)
        Me.TextBox3.TabIndex = 0
        '
        'bttn_delete
        '
        Me.bttn_delete.BackColor = System.Drawing.Color.DarkGray
        Me.bttn_delete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttn_delete.Image = CType(resources.GetObject("bttn_delete.Image"), System.Drawing.Image)
        Me.bttn_delete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bttn_delete.Location = New System.Drawing.Point(567, 639)
        Me.bttn_delete.Name = "bttn_delete"
        Me.bttn_delete.Size = New System.Drawing.Size(65, 33)
        Me.bttn_delete.TabIndex = 70
        Me.bttn_delete.Text = "Delete"
        Me.bttn_delete.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.bttn_delete.UseVisualStyleBackColor = False
        '
        'bttn_update
        '
        Me.bttn_update.BackColor = System.Drawing.Color.DarkGray
        Me.bttn_update.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttn_update.Image = CType(resources.GetObject("bttn_update.Image"), System.Drawing.Image)
        Me.bttn_update.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bttn_update.Location = New System.Drawing.Point(460, 639)
        Me.bttn_update.Name = "bttn_update"
        Me.bttn_update.Size = New System.Drawing.Size(65, 33)
        Me.bttn_update.TabIndex = 69
        Me.bttn_update.Text = "Update"
        Me.bttn_update.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.bttn_update.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-1, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(147, 134)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 71
        Me.PictureBox1.TabStop = False
        '
        'bttn_clear
        '
        Me.bttn_clear.BackColor = System.Drawing.Color.DarkGray
        Me.bttn_clear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.bttn_clear.Image = CType(resources.GetObject("bttn_clear.Image"), System.Drawing.Image)
        Me.bttn_clear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.bttn_clear.Location = New System.Drawing.Point(255, 639)
        Me.bttn_clear.Name = "bttn_clear"
        Me.bttn_clear.Size = New System.Drawing.Size(65, 33)
        Me.bttn_clear.TabIndex = 72
        Me.bttn_clear.Text = "Clear"
        Me.bttn_clear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.bttn_clear.UseVisualStyleBackColor = False
        '
        'payroll
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.BOC.My.Resources.Resources._1272AD4B_2385_42EC_AD32_3D7BA3438412
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1365, 689)
        Me.Controls.Add(Me.bttn_clear)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.bttn_delete)
        Me.Controls.Add(Me.bttn_update)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.nonworking)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Reg)
        Me.Controls.Add(Me.Regular)
        Me.Controls.Add(Me.special)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.absent)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Tardiness)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.otpay)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.hrworked)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.totalsal)
        Me.Controls.Add(Me.basicpay)
        Me.Controls.Add(Me.bttn_back)
        Me.Controls.Add(Me.bttn_payslip)
        Me.Controls.Add(Me.bttn_insert)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.netpay)
        Me.Controls.Add(Me.totaldeduc)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.otherloan)
        Me.Controls.Add(Me.phloan)
        Me.Controls.Add(Me.sssloan)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.philh)
        Me.Controls.Add(Me.pagibig)
        Me.Controls.Add(Me.sss)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.OT)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.payrollid)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DateTimePicker2_PERIOD_END)
        Me.Controls.Add(Me.DateTimePicker1_PERIOD_START)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "payroll"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Payroll"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DateTimePicker1_PERIOD_START As DateTimePicker
    Friend WithEvents DateTimePicker2_PERIOD_END As DateTimePicker
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents payrollid As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents OT As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents otherloan As TextBox
    Friend WithEvents phloan As TextBox
    Friend WithEvents sssloan As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents philh As TextBox
    Friend WithEvents pagibig As TextBox
    Friend WithEvents sss As TextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents netpay As TextBox
    Friend WithEvents totaldeduc As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents bttn_insert As Button
    Friend WithEvents bttn_payslip As Button
    Friend WithEvents bttn_back As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents totalsal As TextBox
    Friend WithEvents basicpay As TextBox
    Friend WithEvents hrworked As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents otpay As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Tardiness As TextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents absent As TextBox
    Friend WithEvents Label21 As Label
    Friend WithEvents special As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Reg As TextBox
    Friend WithEvents Regular As Label
    Friend WithEvents nonworking As TextBox
    Friend WithEvents Label24 As Label
    Friend WithEvents PrintDocument1 As Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As PrintPreviewDialog
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents bttn_delete As Button
    Friend WithEvents bttn_update As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents bttn_clear As Button
End Class
