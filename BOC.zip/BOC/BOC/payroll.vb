﻿Imports MySql.Data.MySqlClient

Public Class payroll

    Dim con As New MySqlConnection
    Dim cmd As New MySqlCommand
    Dim dr As MySqlDataReader

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1_PERIOD_START.ValueChanged

        con.ConnectionString = "server=localhost;username=root;password=;Persist Security Info=True;database=boc;Convert Zero Datetime=True"


        If DateTimePicker1_PERIOD_START.Value.Day <= 15 Then

            Dim diffdate As Integer

            diffdate = 15 - DateTimePicker1_PERIOD_START.Value.Day
            DateTimePicker2_PERIOD_END.Value = (DateTimePicker1_PERIOD_START.Value.AddDays(diffdate))

            payrollid.Text = "BOC" & DateTimePicker2_PERIOD_END.Value.Month & DateTimePicker2_PERIOD_END.Value.Day & DateTimePicker2_PERIOD_END.Value.Year

        Else

            Dim diffdate As Integer

            diffdate = 30 - DateTimePicker1_PERIOD_START.Value.Day
            DateTimePicker2_PERIOD_END.Value = (DateTimePicker1_PERIOD_START.Value.AddDays(diffdate))

            payrollid.Text = "BOC" & DateTimePicker2_PERIOD_END.Value.Month & DateTimePicker2_PERIOD_END.Value.Day & DateTimePicker2_PERIOD_END.Value.Year

        End If

    End Sub

    Private Sub payroll_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        con = New MySqlConnection
        cmd = con.CreateCommand()
        con.ConnectionString = "server=localhost;username=root;password=;database=boc"

        cmd.CommandType = CommandType.Text
        cmd.CommandText = "select * from payroll"
        con.Open()
        con.Close()

        Dim dt As New DataTable()
        Dim mydata As New MySqlDataAdapter(cmd)

        mydata.Fill(dt)
        DataGridView2.DataSource = dt


    End Sub

    Private Sub hrworked_TextChanged(sender As Object, e As EventArgs) Handles hrworked.TextChanged

        basicpay.Text = Val(hrworked.Text) * 52.5

        totalsal.Text = Val(basicpay.Text)

        sss.Text = Val(totalsal.Text) * 0.025
        pagibig.Text = Val(totalsal.Text) * 0.025
        philh.Text = Val(totalsal.Text) * 0.025
        totaldeduc.Text = Val(sss.Text) + Val(pagibig.Text) + Val(philh.Text) + Val(sssloan.Text) + Val(phloan.Text) + Val(otherloan.Text)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub sssloan_TextChanged(sender As Object, e As EventArgs) Handles sssloan.TextChanged

        totaldeduc.Text = Val(sss.Text) + Val(pagibig.Text) + Val(philh.Text) + Val(sssloan.Text) + Val(phloan.Text) + Val(otherloan.Text)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub phloan_TextChanged(sender As Object, e As EventArgs) Handles phloan.TextChanged

        totaldeduc.Text = Val(sss.Text) + Val(pagibig.Text) + Val(philh.Text) + Val(sssloan.Text) + Val(phloan.Text) + Val(otherloan.Text)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub otherloan_TextChanged(sender As Object, e As EventArgs) Handles otherloan.TextChanged

        totaldeduc.Text = Val(sss.Text) + Val(pagibig.Text) + Val(philh.Text) + Val(sssloan.Text) + Val(phloan.Text) + Val(otherloan.Text)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Dim ExitYN As System.Windows.Forms.DialogResult

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles bttn_back.Click

        AddPrint.Show()
        Me.Hide()

        TextBox1.Clear()
        TextBox2.Clear()
        hrworked.Text = "0"
        OT.Text = "0"
        special.Text = "0"
        nonworking.Text = "0"
        Reg.Text = "0"
        sssloan.Text = "0"
        phloan.Text = "0"
        otherloan.Text = "0"
        absent.Text = "0"
        Tardiness.Text = "0"
        payrollid.Text = ""
        DateTimePicker1_PERIOD_START.Value = Today
        DateTimePicker2_PERIOD_END.Value = Today

    End Sub

    Private Sub OT_TextChanged(sender As Object, e As EventArgs) Handles OT.TextChanged

        otpay.Text = Val(OT.Text) * 65
        totalsal.Text = Val(basicpay.Text) + Val(otpay.Text)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles bttn_insert.Click

        Dim con As New MySqlConnection
        Dim cmd As New MySqlCommand
        Dim dr As MySqlDataReader
        con.ConnectionString = "server=localhost;username=root;password=;Persist Security Info=True;database=boc;Convert Zero Datetime=True"

        Try
            con.Open()
            cmd.Connection = con
            cmd.CommandType = CommandType.Text
            cmd.CommandText = "select * from payroll where EMPLOYEE_ID='" & TextBox1.Text & "'"
            dr = cmd.ExecuteReader

            If dr.HasRows Then

                MsgBox("Employee Id Already Registered", MsgBoxStyle.Critical)
                con.Close()

            Else

                con.Close()
                con.Open()
                cmd.CommandText = "INSERT INTO payroll (`EMPLOYEE_ID`, `EMPLOYEE_NAME`, `PERIOD_START`, `PERIOD_END`, `HR_WORKED`, `BASIC_PAY`, `OVERTIME`,`OVERTIME_PAY`,`TOTAL_SALARY`,`SSS`,`PAG_IBIG`,`PHILHEALTH`,`SSS_LOANS`,`PHILHEALTH_LOANS`,`OTHER_LOANS`,`TOTAL_DEDUCTION`,`NETPAY`,`S_Working_Holiday`,`SNonWorkingHoliday`,`Regular_Holiday`,`Tardiness`,`Absent`,`Payrollid`) VALUES
                ('" & TextBox1.Text & "', '" & TextBox2.Text & "','" & DateTimePicker1_PERIOD_START.Value & "','" & DateTimePicker2_PERIOD_END.Value & "', '" & hrworked.Text & "', '" & basicpay.Text & "', '" & OT.Text & "' , '" & otpay.Text & "' , '" & totalsal.Text & "' , '" & sss.Text & "', '" & pagibig.Text & "', '" & philh.Text & "', '" & sssloan.Text & "', '" & phloan.Text & "', '" & otherloan.Text & "', '" & totaldeduc.Text & "', '" & netpay.Text & "', '" & special.Text & "', '" & nonworking.Text & "', '" & Reg.Text & "', '" & Tardiness.Text & "', '" & absent.Text & "', '" & payrollid.Text & "' )"

                If (TextBox2.Text = "" Or DateTimePicker1_PERIOD_START.Text = "" Or DateTimePicker2_PERIOD_END.Text = "" Or hrworked.Text = "0" Or basicpay.Text = "" Or OT.Text = "0" Or otpay.Text = "0" Or totalsal.Text = "0" And sss.Text = "" Or pagibig.Text = "0" Or philh.Text = "0" Or sssloan.Text = "0" Or phloan.Text = "0" Or otherloan.Text = "0" Or totaldeduc.Text = "0" Or netpay.Text = "0") Then

                    MessageBox.Show("Please enter the details")

                Else

                    cmd.ExecuteNonQuery()
                    MsgBox("Data Inserted Successfully.", MsgBoxStyle.Information, "Save")

                    TextBox1.Clear()
                    TextBox2.Clear()
                    hrworked.Text = "0"
                    OT.Text = "0"
                    special.Text = "0"
                    nonworking.Text = "0"
                    Reg.Text = "0"
                    sssloan.Text = "0"
                    phloan.Text = "0"
                    otherloan.Text = "0"
                    absent.Text = "0"
                    Tardiness.Text = "0"
                    payrollid.Text = ""
                    DateTimePicker1_PERIOD_START.Value = Today
                    DateTimePicker2_PERIOD_END.Value = Today

                End If

            End If

            con.Close()

        Catch ex As Exception

            MsgBox(ex.ToString)

        End Try

        Dim str As String

        Try

            str = "SELECT * FROM payroll"

            con.Open()

            Dim da As New MySqlDataAdapter(str, con)

            Dim dt As New DataTable

            da.Fill(dt)

            DataGridView2.DataSource = dt

            con.Close()


        Catch ex As Exception

            MsgBox(ex.Message)

            con.Close()

        End Try

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles Tardiness.TextChanged

        totaldeduc.Text = Val(sss.Text) + Val(pagibig.Text) + Val(philh.Text) + Val(sssloan.Text) + Val(phloan.Text) + Val(otherloan.Text) + (Val(Tardiness.Text) * 52.5) + (Val(absent.Text) * 420)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub absent_TextChanged(sender As Object, e As EventArgs) Handles absent.TextChanged

        totaldeduc.Text = Val(sss.Text) + Val(pagibig.Text) + Val(philh.Text) + Val(sssloan.Text) + Val(phloan.Text) + Val(otherloan.Text) + (Val(Tardiness.Text) * 52.5) + (Val(absent.Text) * 420)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub payroll_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing

        Dim f As DialogResult

        f = MessageBox.Show("Do you really want to close this system?", "Exit", MessageBoxButtons.YesNo)

        If f = Windows.Forms.DialogResult.No Then

            e.Cancel = True

        Else

            Application.ExitThread()

        End If

    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub hrworked_KeyPress(sender As Object, e As KeyPressEventArgs) Handles hrworked.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub OT_KeyPress(sender As Object, e As KeyPressEventArgs) Handles OT.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub Tardiness_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Tardiness.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub sssloan_KeyPress(sender As Object, e As KeyPressEventArgs) Handles sssloan.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub phloan_KeyPress(sender As Object, e As KeyPressEventArgs) Handles phloan.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub otherloan_KeyPress(sender As Object, e As KeyPressEventArgs) Handles otherloan.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub absent_KeyPress(sender As Object, e As KeyPressEventArgs) Handles absent.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub special_KeyPress(sender As Object, e As KeyPressEventArgs) Handles special.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub nonworking_KeyPress(sender As Object, e As KeyPressEventArgs) Handles nonworking.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub Reg_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Reg.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then

                e.Handled = True
                MessageBox.Show("You can only input numbers in this field")

            End If

        End If

    End Sub

    Private Sub hrworked_Enter(sender As Object, e As EventArgs) Handles hrworked.Enter

        If hrworked.Text = "0" Then

            hrworked.Text = ""
            hrworked.ForeColor = Color.Black

        End If

    End Sub

    Private Sub hrworked_Leave(sender As Object, e As EventArgs) Handles hrworked.Leave

        If hrworked.Text = "" Then

            hrworked.Text = "0"
            hrworked.ForeColor = Color.Black

        End If

    End Sub

    Private Sub OT_Enter(sender As Object, e As EventArgs) Handles OT.Enter

        If OT.Text = "0" Then

            OT.Text = ""
            OT.ForeColor = Color.Black

        End If

    End Sub

    Private Sub OT_Leave(sender As Object, e As EventArgs) Handles OT.Leave

        If OT.Text = "" Then

            OT.Text = "0"
            OT.ForeColor = Color.Black

        End If

    End Sub

    Private Sub sssloan_Enter(sender As Object, e As EventArgs) Handles sssloan.Enter

        If sssloan.Text = "0" Then

            sssloan.Text = ""
            sssloan.ForeColor = Color.Black

        End If

    End Sub

    Private Sub sssloan_Leave(sender As Object, e As EventArgs) Handles sssloan.Leave

        If sssloan.Text = "" Then

            sssloan.Text = "0"
            sssloan.ForeColor = Color.Black

        End If

    End Sub

    Private Sub phloan_Enter(sender As Object, e As EventArgs) Handles phloan.Enter

        If phloan.Text = "0" Then

            phloan.Text = ""
            phloan.ForeColor = Color.Black

        End If

    End Sub

    Private Sub phloan_Leave(sender As Object, e As EventArgs) Handles phloan.Leave

        If phloan.Text = "" Then

            phloan.Text = "0"
            phloan.ForeColor = Color.Black

        End If

    End Sub

    Private Sub otherloan_Enter(sender As Object, e As EventArgs) Handles otherloan.Enter

        If otherloan.Text = "0" Then

            otherloan.Text = ""
            otherloan.ForeColor = Color.Black

        End If

    End Sub

    Private Sub otherloan_Leave(sender As Object, e As EventArgs) Handles otherloan.Leave

        If otherloan.Text = "" Then

            otherloan.Text = "0"
            otherloan.ForeColor = Color.Black

        End If

    End Sub

    Private Sub absent_Enter(sender As Object, e As EventArgs) Handles absent.Enter

        If absent.Text = "0" Then

            absent.Text = ""
            absent.ForeColor = Color.Black

        End If

    End Sub

    Private Sub absent_Leave(sender As Object, e As EventArgs) Handles absent.Leave

        If absent.Text = "" Then

            absent.Text = "0"
            absent.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Tardiness_Enter(sender As Object, e As EventArgs) Handles Tardiness.Enter

        If Tardiness.Text = "0" Then

            Tardiness.Text = ""
            Tardiness.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Tardiness_Leave(sender As Object, e As EventArgs) Handles Tardiness.Leave

        If Tardiness.Text = "" Then

            Tardiness.Text = "0"
            Tardiness.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles bttn_payslip.Click

        If (TextBox1.Text = "" Or TextBox2.Text = "" Or DateTimePicker1_PERIOD_START.Text = "" Or DateTimePicker2_PERIOD_END.Text = "" Or hrworked.Text = "0" Or basicpay.Text = "" Or OT.Text = "0" Or otpay.Text = "0" Or totalsal.Text = "0" And sss.Text = "" Or pagibig.Text = "0" Or philh.Text = "0" Or sssloan.Text = "0" Or phloan.Text = "0" Or otherloan.Text = "0" Or totaldeduc.Text = "0" Or netpay.Text = "0") Then

            MessageBox.Show("Please select details to print")

        Else

            TextBox3.Text = ""
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText(vbTab + vbTab + vbTab + vbTab + vbTab & "BLACK OLIVES CAFE" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + vbTab + vbTab + vbTab & "McArthur Highway, Sampaloc, Apalit, Pampanga" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + vbTab + vbTab + vbTab + vbTab & "CONTACT No.: 09157183388" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Period Start: " + vbTab & DateTimePicker1_PERIOD_START.Value + vbTab + vbTab + vbTab + vbTab + vbTab + "Payroll ID: " & payrollid.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Period End: " + vbTab & DateTimePicker2_PERIOD_END.Value + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Employee ID: " + vbTab + vbTab & TextBox1.Text + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Employee Name: " + vbTab & TextBox2.Text + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "No. of Hr Worked: " + vbTab & hrworked.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Basic Salary: " + vbTab & basicpay.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + vbTab + "Overtime: " + vbTab & OT.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Overtime Pay: " + vbTab & otpay.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "S. Working Holiday: " + vbTab & special.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Regular Holiday: " & Reg.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "S. Non-Working Holiday: " & nonworking.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Total Salary: " + vbTab & totalsal.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "DEDUCTIONS" + vbTab + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "SSS: " + vbTab + vbTab + vbTab & sss.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "SSS Loan: " + vbTab & sssloan.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Pag-Ibig: " + vbTab + vbTab & pagibig.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Pag-Ibig Loan: " + vbTab & phloan.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Philhealth: " + vbTab + vbTab & philh.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Other Loan: " + vbTab & otherloan.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Tardiness: " + vbTab + vbTab & Tardiness.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Absentees: " + vbTab & absent.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Total Decutions: " + vbTab & totaldeduc.Text + vbTab + vbTab + vbTab + vbTab + vbTab + "Net Pay: " + vbTab & netpay.Text + vbTab + vbTab + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText("------------------------------------------------------------------------------------------------------------------------------------------------------" + vbNewLine)

            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Date: " + vbTab + Format(Now, "MMMM dd, yyyy") & vbTab + vbTab + vbTab + vbTab + vbTab + vbTab & "Time: " + vbTab & Format(Now, "hh:mm:ss tt") + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText(vbTab + "Received by:" + "   ___________________" + vbNewLine)
            TextBox3.AppendText(vbTab + vbTab + vbTab + TextBox2.Text + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)
            TextBox3.AppendText("" + vbNewLine)

            TextBox3.AppendText(vbTab + vbTab + vbTab + PictureBox1.Text + vbNewLine)

            PrintPreviewDialog1.PrintPreviewControl.Zoom = 1
            PrintPreviewDialog1.ShowDialog()

        End If

    End Sub

    Private Sub special_TextChanged(sender As Object, e As EventArgs) Handles special.TextChanged

        totalsal.Text = Val(basicpay.Text) + Val(otpay.Text) + (Val(special.Text) * 126) + (Val(nonworking.Text) * 126)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)


    End Sub

    Private Sub nonworking_TextChanged(sender As Object, e As EventArgs) Handles nonworking.TextChanged

        totalsal.Text = Val(basicpay.Text) + Val(otpay.Text) + (Val(nonworking.Text) * 126) + (Val(special.Text) * 126)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub Reg_TextChanged(sender As Object, e As EventArgs) Handles Reg.TextChanged

        totalsal.Text = Val(basicpay.Text) + Val(otpay.Text) + (Val(Reg.Text) * 420) + (Val(nonworking.Text) * 126) + (Val(special.Text) * 126)
        netpay.Text = Val(totalsal.Text) - Val(totaldeduc.Text)

    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress

        If Asc(e.KeyChar) <> 8 And Asc(e.KeyChar) <> 32 Then

            If Asc(e.KeyChar) < 65 Or Asc(e.KeyChar) > 90 And Asc(e.KeyChar) < 97 Or Asc(e.KeyChar) > 122 Then

                e.Handled = True
                MessageBox.Show("You can only input letters in this field")

            End If

        End If

    End Sub

    Private Sub special_Enter(sender As Object, e As EventArgs) Handles special.Enter

        If special.Text = "0" Then

            special.Text = ""
            special.ForeColor = Color.Black

        End If

    End Sub

    Private Sub special_Leave(sender As Object, e As EventArgs) Handles special.Leave

        If special.Text = "" Then

            special.Text = "0"
            special.ForeColor = Color.Black

        End If

    End Sub

    Private Sub nonworking_Enter(sender As Object, e As EventArgs) Handles nonworking.Enter

        If nonworking.Text = "0" Then

            nonworking.Text = ""
            nonworking.ForeColor = Color.Black

        End If

    End Sub

    Private Sub nonworking_Leave(sender As Object, e As EventArgs) Handles nonworking.Leave

        If nonworking.Text = "" Then

            nonworking.Text = "0"
            nonworking.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Reg_Enter(sender As Object, e As EventArgs) Handles Reg.Enter

        If Reg.Text = "0" Then

            Reg.Text = ""
            Reg.ForeColor = Color.Black

        End If

    End Sub

    Private Sub Reg_Leave(sender As Object, e As EventArgs) Handles Reg.Leave

        If Reg.Text = "" Then

            Reg.Text = "0"
            Reg.ForeColor = Color.Black

        End If

    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        ''e.Graphics.DrawString(TextBox3.Text, Font, Brushes.Black, 140, 140)
        e.Graphics.DrawString(TextBox3.Text, New Font("Arial", 8, FontStyle.Bold), Brushes.Black, 140, 140)
        e.Graphics.DrawImage(Me.PictureBox1.Image, 100, 100, PictureBox1.Width - 10, PictureBox1.Height - 20)

    End Sub

    Private Sub update_bttn_Click(sender As Object, e As EventArgs) Handles bttn_update.Click

        If (TextBox1.Text = "" Or TextBox2.Text = "" Or DateTimePicker1_PERIOD_START.Text = "" Or DateTimePicker2_PERIOD_END.Text = "" Or hrworked.Text = "0" Or basicpay.Text = "" Or OT.Text = "0" Or otpay.Text = "0" Or totalsal.Text = "0" And sss.Text = "" Or pagibig.Text = "0" Or philh.Text = "0" Or sssloan.Text = "0" Or phloan.Text = "0" Or otherloan.Text = "0" Or totaldeduc.Text = "0" Or netpay.Text = "0") Then

            MessageBox.Show("Please enter the complete details to update")

        Else

            con = New MySqlConnection
            con.ConnectionString = "server=localhost;username=root;password=;Persist Security Info=True;database=boc;Convert Zero Datetime=True"
            Dim reader As MySqlDataReader

            Try

                con.Open()
                Dim query As String
                query = "update payroll set EMPLOYEE_ID='" & TextBox1.Text & "', EMPLOYEE_NAME='" & TextBox2.Text & "', PERIOD_START='" & DateTimePicker1_PERIOD_START.Value & "', 
                PERIOD_END='" & DateTimePicker2_PERIOD_END.Value & "', HR_WORKED='" & hrworked.Text & "', BASIC_PAY='" & basicpay.Text & "', 
                OVERTIME='" & OT.Text & "',  OVERTIME_PAY='" & otpay.Text & "', TOTAL_SALARY='" & totalsal.Text & "', SSS='" & sss.Text & "', PAG_IBIG='" & pagibig.Text & "', 
                PHILHEALTH='" & philh.Text & "', SSS_LOANS='" & sssloan.Text & "', PHILHEALTH_LOANS='" & phloan.Text & "', OTHER_LOANS='" & otherloan.Text & "', 
                TOTAL_DEDUCTION='" & totaldeduc.Text & "', NETPAY='" & netpay.Text & "', S_Working_Holiday='" & special.Text & "', SNonWorkingHoliday='" & nonworking.Text & "', Regular_Holiday='" & Reg.Text & "', Tardiness='" & Tardiness.Text & "', Absent='" & absent.Text & "', Payrollid='" & payrollid.Text & "' where EMPLOYEE_ID='" & TextBox1.Text & "' "

                cmd = New MySqlCommand(query, con)
                reader = cmd.ExecuteReader()

                MessageBox.Show("Data Updated Successfully!")
                con.Close()

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Dim str As String

            Try

                str = "SELECT * FROM payroll"

                con.Open()

                Dim da As New MySqlDataAdapter(str, con)

                Dim dt As New DataTable

                da.Fill(dt)

                DataGridView2.DataSource = dt

                con.Close()


            Catch ex As Exception

                MsgBox(ex.Message)

                con.Close()

            End Try

            TextBox1.Clear()
            TextBox2.Clear()
            hrworked.Text = "0"
            OT.Text = "0"
            special.Text = "0"
            nonworking.Text = "0"
            Reg.Text = "0"
            sssloan.Text = "0"
            phloan.Text = "0"
            otherloan.Text = "0"
            absent.Text = "0"
            Tardiness.Text = "0"
            payrollid.Text = ""
            DateTimePicker1_PERIOD_START.Value = Today
            DateTimePicker2_PERIOD_END.Value = Today

        End If


    End Sub

    Private Sub delete_bttn_Click(sender As Object, e As EventArgs) Handles bttn_delete.Click

        If TextBox1.Text = "" Then

            MessageBox.Show("Please input an Employee ID to delete a data")

        Else

            con = New MySqlConnection
            con.ConnectionString = "server=localhost; username=root; password=; database=boc"
            Dim reader As MySqlDataReader

            Try

                con.Open()
                Dim query As String
                query = "Delete from payroll where EMPLOYEE_ID='" & TextBox1.Text & "' "
                cmd = New MySqlCommand(query, con)
                reader = cmd.ExecuteReader()

                MessageBox.Show("Data Deleted Successfully!")
                con.Close()

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Try

                con.Open()
                Dim querryy As String
                querryy = "Alter Table payroll AUTO_INCREMENT = 1"
                cmd = New MySqlCommand(querryy, con)
                reader = cmd.ExecuteReader()

                con.Close()

            Catch ex As Exception

                MessageBox.Show(ex.Message)

            Finally

                con.Dispose()

            End Try

            Dim str As String

            Try

                str = "SELECT * FROM payroll"

                con.Open()

                Dim da As New MySqlDataAdapter(str, con)

                Dim dt As New DataTable

                da.Fill(dt)

                DataGridView2.DataSource = dt

                con.Close()


            Catch ex As Exception

                MsgBox(ex.Message)

                con.Close()

            End Try

            TextBox1.Clear()
            TextBox2.Clear()
            hrworked.Text = "0"
            OT.Text = "0"
            special.Text = "0"
            nonworking.Text = "0"
            Reg.Text = "0"
            sssloan.Text = "0"
            phloan.Text = "0"
            otherloan.Text = "0"
            absent.Text = "0"
            Tardiness.Text = "0"
            payrollid.Text = ""
            DateTimePicker1_PERIOD_START.Value = Today
            DateTimePicker2_PERIOD_END.Value = Today

        End If


    End Sub

    Private Sub clear_bttn_Click(sender As Object, e As EventArgs) Handles bttn_clear.Click

        TextBox1.Clear()
        TextBox2.Clear()
        hrworked.Text = "0"
        OT.Text = "0"
        special.Text = "0"
        nonworking.Text = "0"
        Reg.Text = "0"
        sssloan.Text = "0"
        phloan.Text = "0"
        otherloan.Text = "0"
        absent.Text = "0"
        Tardiness.Text = "0"
        payrollid.Text = ""
        DateTimePicker1_PERIOD_START.Value = Today
        DateTimePicker2_PERIOD_END.Value = Today

    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick

        Try

            If e.RowIndex >= 0 Then

                Dim row As DataGridViewRow
                row = Me.DataGridView2.Rows(e.RowIndex)

                TextBox1.Text = row.Cells("EMPLOYEE_ID").Value.ToString
                TextBox2.Text = row.Cells("EMPLOYEE_NAME").Value.ToString
                DateTimePicker1_PERIOD_START.Value = row.Cells("PERIOD_START").Value.ToString
                DateTimePicker2_PERIOD_END.Value = row.Cells("PERIOD_END").Value.ToString
                hrworked.Text = row.Cells("HR_WORKED").Value.ToString
                basicpay.Text = row.Cells("BASIC_PAY").Value.ToString
                OT.Text = row.Cells("OVERTIME").Value.ToString
                otpay.Text = row.Cells("OVERTIME_PAY").Value.ToString
                totalsal.Text = row.Cells("TOTAL_SALARY").Value.ToString
                sss.Text = row.Cells("SSS").Value.ToString
                pagibig.Text = row.Cells("PAG_IBIG").Value.ToString
                philh.Text = row.Cells("PHILHEALTH").Value.ToString
                sssloan.Text = row.Cells("SSS_LOANS").Value.ToString
                phloan.Text = row.Cells("PHILHEALTH_LOANS").Value.ToString
                otherloan.Text = row.Cells("OTHER_LOANS").Value.ToString
                totaldeduc.Text = row.Cells("TOTAL_DEDUCTION").Value.ToString
                netpay.Text = row.Cells("NETPAY").Value.ToString
                special.Text = row.Cells("S_Working_Holiday").Value.ToString
                nonworking.Text = row.Cells("SNonWorkingHoliday").Value.ToString
                Reg.Text = row.Cells("Regular_Holiday").Value.ToString
                Tardiness.Text = row.Cells("Tardiness").Value.ToString
                absent.Text = row.Cells("Absent").Value.ToString
                payrollid.Text = row.Cells("Payrollid").Value.ToString

            End If

        Catch ex As Exception

            MessageBox.Show(ex.Message)

        End Try

    End Sub

End Class